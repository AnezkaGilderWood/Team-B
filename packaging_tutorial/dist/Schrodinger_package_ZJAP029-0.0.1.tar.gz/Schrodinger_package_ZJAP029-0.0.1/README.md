# Schrodinger Equation Solver

This package ....

Features
---------

How to install
---------------


Credit
------
Source Code: https://github.com/AnezkaGilderWood/Team-B
Authors: Anezka Gilder-Wood, Matt Bull, George Wright, Jack Smith, James Gathercole, Anusheh Stanton, Max Downer
This software is licensed under the MIT license.
